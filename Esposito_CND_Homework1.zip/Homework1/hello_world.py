#Michael Esposito
#Computer Network Defense
#CSCI 6542
#1/26/17
#hello_world.py

print "Hello World"